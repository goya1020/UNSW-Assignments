import numpy as np
#[0, 20, 0, 0, -10, -20],
# coefficient matrix
coefficient_matrix = [[20, -20, -10, 0, 0, 0],
                      [0, 0, 30, 0, -20, 0],
                      [0, -20, -20, 0, 50, -20],
                      [0, 0, 0, -20, -20, 30],
                      [0, 0, 0, 40, 0, -10],
                      [1,1,1,1,1,1]]
coefficient_matrix = np.array(coefficient_matrix)

constant_matrices = [0, 0, 0, 0, 0, 1]
constant_matrices = np.array(constant_matrices)

result = np.linalg.solve(coefficient_matrix, constant_matrices)

list1 = ['0,0,3', '1,0,2', '0,1,2', '2,0,1', '1,1,1', '2,1,0']
list1.reverse()
for x in result:
    print('P({}) is:'.format(list1.pop()), end='\t')
    print(x)
