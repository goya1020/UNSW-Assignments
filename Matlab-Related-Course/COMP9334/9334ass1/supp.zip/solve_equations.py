import numpy as np

# 4 operators and no slot.
# R is lambda, the mean arrival rate.
R = 1/3
# U is the service rate.
U = 1/10

# coefficient matrix
coefficient_matrix = [[R, -U, 0, 0, 0],
            [0, -R, 2*U, 0, 0],
            [0, 0, -R, 3*U, 0],
            [0, 0, 0, -R, 4*U],
            [1, 1, 1, 1, 1]]
coefficient_matrix = np.array(coefficient_matrix)

constant_matrices = [0, 0, 0, 0, 1]
constant_matrices = np.array(constant_matrices)

result = np.linalg.solve(coefficient_matrix, constant_matrices)

print('4 operators with no slots.')
print('From P(0) to P(4) is: ')
for x in result:
    print(' '* 4, x)
print('50% P(4) is : ', 0.5 * result[-1])
print()


# 4 operators and 1 slot.
# R is lambda, the mean arrival rate.
R = 1/3
# U is the service rate.
U = 1/10

# coefficient matrix
coefficient_matrix = [[R, -U, 0, 0, 0, 0],
                      [0, -R, 2*U, 0, 0, 0],
                      [0, 0, -R, 3*U, 0, 0],
                      [0, 0, 0, -R, 4*U, 0],
                        [0, 0, 0, 0, -R, 4*U],
                      [1, 1, 1, 1, 1, 1]]
coefficient_matrix = np.array(coefficient_matrix)

constant_matrices = [0, 0, 0, 0, 0, 1]
constant_matrices = np.array(constant_matrices)

result = np.linalg.solve(coefficient_matrix, constant_matrices)


print('4 operators and 1 slot.')
print('P(0) IS P(0,0) P(1) IS P(1,0) ... P(5) IS P(4,1)')
print('From P(0) to P(5) is: ')
for x in result:
    print(' '* 4, x)



# 4 operators and 2 slots.
# R is lambda, the mean arrival rate.
R = 1/3
# U is the service rate.
U = 1/10

# coefficient matrix
coefficient_matrix = [[R, -U, 0, 0, 0, 0, 0],
                      [0, -R, 2*U, 0, 0, 0, 0],
                      [0, 0, -R, 3*U, 0, 0, 0],
                      [0, 0, 0, -R, 4*U, 0, 0],
                        [0, 0, 0, 0, -R, 4*U, 0],
                        [0, 0, 0, 0, 0, -R, 4*U],
                      [1, 1, 1, 1, 1, 1, 1]]
coefficient_matrix = np.array(coefficient_matrix)

constant_matrices = [0, 0, 0, 0, 0, 0, 1]
constant_matrices = np.array(constant_matrices)

result = np.linalg.solve(coefficient_matrix, constant_matrices)

print()
print('4 operators and 2 slots.')
print('P(0) IS P(0,0) P(1) IS P(1,0) ... P(5) IS P(4,1), P(6) IS P(4,2) ')
print('From P(0) to P(6) is: ')
for x in result:
    print(' '* 4, x)



# 4 operators and 3 slot.
# R is lambda, the mean arrival rate.
R = 1/3
# U is the service rate.
U = 1/10

# coefficient matrix
coefficient_matrix = [[R, -U, 0, 0, 0, 0, 0, 0],
                      [0, -R, 2*U, 0, 0, 0, 0, 0],
                      [0, 0, -R, 3*U, 0, 0, 0, 0],
                      [0, 0, 0, -R, 4*U, 0, 0, 0],
                        [0, 0, 0, 0, -R, 4*U, 0, 0],
                        [0, 0, 0, 0, 0, -R, 4*U, 0],
                        [0, 0, 0, 0, 0, 0, -R, 4*U,],
                      [1, 1, 1, 1, 1, 1, 1, 1]]
coefficient_matrix = np.array(coefficient_matrix)

constant_matrices = [0, 0, 0, 0, 0, 0, 0, 1]
constant_matrices = np.array(constant_matrices)

result = np.linalg.solve(coefficient_matrix, constant_matrices)

print()
print('4 operators and 3 slots.')
print('P(0) IS P(0,0) P(1) IS P(1,0) ... P(5) IS P(4,1), P(6) IS P(4,2), P(7) IS P(4,3)')
print('From P(0) to P(6) is: ')
for x in result:
    print(' '* 4, x)

